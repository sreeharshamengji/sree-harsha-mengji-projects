<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// Get data from the frontend
$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    echo json_encode(["success" => false, "message" => "No data received"]);
    exit;
}

// Debugging: Log received data
error_log(print_r($data, true));

$test_id = $data['test_id'];
$user_id = $data['user_id'];
$marks_obtained = $data['marks_obtained'];
$total_marks = $data['total_marks'];

// Insert the result into the database
$query = "INSERT INTO test_results (user_id, test_id, marks_obtained, total_marks) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["success" => false, "message" => "Failed to prepare statement"]);
    exit;
}

$stmt->bind_param("iiii", $user_id, $test_id, $marks_obtained, $total_marks);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Test submitted successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to submit test"]);
}

$stmt->close();
$conn->close();
?>