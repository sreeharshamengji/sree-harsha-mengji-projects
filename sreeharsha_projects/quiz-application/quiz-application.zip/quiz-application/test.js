// function fetchQuestions(subject, setNumber) {
//     fetch(`fetch_questions.php?subject=${subject}&set=${setNumber}`)
//         .then(response => response.json())
//         .then(data => {
//             if (data.error) {
//                 console.error("Error:", data.error);
//             } else {
//                 displayQuestions(data);
//             }
//         })
//         .catch(error => console.error("Fetch error:", error));
// }

// function displayQuestions(questions) {
//     let container = document.getElementById("test-container");
//     container.innerHTML = "";
    
//     questions.forEach((q, index) => {
//         let questionHtml = `
//             <div class="question-card">
//                 <p><b>Q${index + 1}:</b> ${q.question}</p>
//                 <input type="radio" name="q${q.id}" value="1"> ${q.option_1} <br>
//                 <input type="radio" name="q${q.id}" value="2"> ${q.option_2} <br>
//                 <input type="radio" name="q${q.id}" value="3"> ${q.option_3} <br>
//                 <input type="radio" name="q${q.id}" value="4"> ${q.option_4} <br>
//             </div>
//         `;
//         container.innerHTML += questionHtml;
//     });
// }

// // Example call:
// fetchQuestions("math", 1); // Fetch questions from 'math_1'
