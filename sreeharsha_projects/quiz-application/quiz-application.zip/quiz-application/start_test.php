<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

$test_id = $_GET['test_id'];

if (!$test_id) {
    echo json_encode(["success" => false, "message" => "Invalid test ID"]);
    exit;
}

// Fetch test details (subject, number of sets, duration, time)
$query = "SELECT subject, no_of_set, duration, time FROM tests WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $test_id);
$stmt->execute();
$result = $stmt->get_result();
$test = $result->fetch_assoc();
$stmt->close();

if (!$test) {
    echo json_encode(["success" => false, "message" => "Test not found"]);
    exit;
}

$subject = $test['subject'];
$no_of_set = $test['no_of_set'];
$duration = $test['duration'];
$test_time = $test['time'];

$questions_by_set = [];
$marks_by_set = [];

// Get question count and marks from `test_sets`
$query = "SELECT set_number, question_count, marks_allotted FROM test_sets WHERE test_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $test_id);
$stmt->execute();
$result = $stmt->get_result();

$set_details = [];
while ($row = $result->fetch_assoc()) {
    $set_details[$row['set_number']] = [
        "question_count" => $row['question_count'],
        "marks_allotted" => $row['marks_allotted']
    ];
}
$stmt->close();

// Fetch questions for each set based on the required count
foreach ($set_details as $set => $details) {
    $table_name = "{$subject}_{$set}";

    // Check if table exists
    $checkTableQuery = "SHOW TABLES LIKE '$table_name'";
    $tableResult = $conn->query($checkTableQuery);
    if ($tableResult->num_rows == 0) {
        continue; // Skip this set if no table exists
    }

    $numQuestions = $details["question_count"];
    $marks_allotted = $details["marks_allotted"];

    // Fetch exact number of random questions
    $query = "SELECT id, question, option_1, option_2, option_3, option_4, correct_option 
              FROM $table_name ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $numQuestions);
    $stmt->execute();
    $result = $stmt->get_result();

    $set_questions = [];
    while ($row = $result->fetch_assoc()) {
        $set_questions[] = $row;
    }

    $questions_by_set["set_$set"] = $set_questions;
    $marks_by_set["set_$set"] = $marks_allotted;
    $stmt->close();
}

// Return data with test duration and time
echo json_encode([
    "success" => true,
    "duration" => $duration,
    "time" => $test_time,
    "questions" => $questions_by_set,
    "marks" => $marks_by_set
]);

$conn->close();
?>
