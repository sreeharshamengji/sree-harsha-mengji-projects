<!-- get_test_questions.php  -->
<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

$subject = $_GET["subject"] ?? "";
if (!$subject) {
    echo json_encode([]);
    exit;
}

$questions = [];
for ($i = 1; $i <= 4; $i++) {
    $tableName = "{$subject}_{$i}";
    $query = "SELECT * FROM $tableName ORDER BY RAND() LIMIT 10"; // Fetch 10 questions from each set
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $questions[] = [
                "question" => $row["question"],
                "options" => [$row["option_1"], $row["option_2"], $row["option_3"], $row["option_4"]],
                "correct_option" => $row["correct_option"]
            ];
        }
    }
}

echo json_encode($questions);
$conn->close();
?>
