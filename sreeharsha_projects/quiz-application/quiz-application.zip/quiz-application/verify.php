<?php
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = json_decode(file_get_contents("php://input"), true);

    if (!isset($input["subject"]) || empty(trim($input["subject"]))) {
        echo json_encode(["success" => false, "message" => "Subject is required."]);
        exit;
    }

    // Sanitize the subject (same as in submit.php)
    function sanitizeName($name) {
        return preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower(trim($name)));
    }
    
    $subject = sanitizeName($input["subject"]);

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "exam";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        echo json_encode(["success" => false, "message" => "Database connection failed."]);
        exit;
    }

    // Check if the subject exists
    $query = "SELECT no_of_set FROM subjects WHERE subject = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        echo json_encode(["success" => false, "message" => "Query preparation failed: " . $conn->error]);
        exit;
    }
    $stmt->bind_param("s", $subject);
    $stmt->execute();
    $stmt->bind_result($no_of_set);
    $stmt->fetch();

    if ($no_of_set) {
        echo json_encode(["success" => true, "no_of_set" => $no_of_set]);
    } else {
        echo json_encode(["success" => false, "message" => "Subject not found."]);
    }

    $stmt->close();
    $conn->close();
}
?>
