<?php
header("Content-Type: application/json");

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

// Fetch test details including the ID
$query = "SELECT id, subject, no_of_set, duration, total_questions, total_marks, date, time FROM tests ORDER BY id DESC";
$result = $conn->query($query);

$tests = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tests[] = $row;
    }
}
echo json_encode($tests);
$conn->close();
?>
