<!-- a.php  -->
<?php
phpinfo();
?>
