<!-- save_questions.php  -->
<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

$testId = $_GET['testId'] ?? 0;

if (!$testId) {
    echo json_encode([]);
    exit;
}

// Fetch questions for the test
$query = "
    SELECT q.question, q.option_1, q.option_2, q.option_3, q.option_4
    FROM test_sets ts
    JOIN questions q ON ts.set_number = q.set_number
    WHERE ts.test_id = ?
    ORDER BY RAND()
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $testId);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $questions[] = [
            "question" => $row["question"],
            "options" => [$row["option_1"], $row["option_2"], $row["option_3"], $row["option_4"]]
        ];
    }
}

echo json_encode($questions);
$conn->close();
?>
