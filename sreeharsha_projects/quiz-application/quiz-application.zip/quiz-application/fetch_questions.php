<?php
require 'db_connect.php'; // Ensure this file connects to your database correctly

$subject = $_GET['subject'];
$set = $_GET['set'];

if (!$subject || !$set) {
    echo json_encode(["error" => "Missing subject or set"]);
    exit;
}

$query = "SELECT * FROM questions WHERE subject = ? AND set_no = ? ORDER BY RAND() LIMIT 10"; 
$stmt = $conn->prepare($query);
$stmt->bind_param("si", $subject, $set);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];
while ($row = $result->fetch_assoc()) {
    $questions[] = $row;
}

if (empty($questions)) {
    echo json_encode(["error" => "No questions found for this test."]);
} else {
    echo json_encode($questions);
}
?>
