<?php
header("Content-Type: application/json");

// Enable error reporting (for debugging; disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "exam";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// Query to fetch all previous tests
$query = "SELECT id, subject, no_of_set, duration, total_questions, total_marks, date, time, deleted_at 
          FROM previous_tests 
          ORDER BY deleted_at DESC";

$result = $conn->query($query);

if (!$result) {
    echo json_encode(["success" => false, "message" => "Query failed: " . $conn->error]);
    exit;
}

$tests = [];
while ($row = $result->fetch_assoc()) {
    $tests[] = $row;
}

// For debugging: Uncomment the next line to see the raw output in your browser
// echo "<pre>" . print_r($tests, true) . "</pre>";

echo json_encode($tests);
$conn->close();
?>
