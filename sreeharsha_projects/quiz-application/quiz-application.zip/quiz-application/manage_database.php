<?php
$servername = "localhost"; // Change if needed
$username = "root"; // Change to your DB username
$password = ""; // Change to your DB password
$dbname = "exam"; // Change to your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete request
if (isset($_POST['delete_subject'])) {
    $subject = $_POST['subject'];

    // Fetch number of sets
    $query = $conn->prepare("SELECT no_of_set FROM subjects WHERE subject = ?");
    $query->bind_param("s", $subject);
    $query->execute();
    $result = $query->get_result();
    $row = $result->fetch_assoc();
    $no_of_set = $row['no_of_set'];

    // Delete subject from the subjects table
    $delete_subject_query = $conn->prepare("DELETE FROM subjects WHERE subject = ?");
    $delete_subject_query->bind_param("s", $subject);
    $delete_subject_query->execute();

    // Delete all related tables (e.g., math_1, math_2)
    for ($i = 1; $i <= $no_of_set; $i++) {
        $table_name = $subject . "_" . $i;
        $drop_table_query = "DROP TABLE IF EXISTS `$table_name`";
        $conn->query($drop_table_query);
    }

    echo "<script>alert('Subject and associated sets deleted successfully!'); window.location.href='manage_database.php';</script>";
}

// Fetch all subjects
$result = $conn->query("SELECT * FROM subjects");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Database</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            flex-direction: column;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #28a745;
            color: white;
        }
        button {
            padding: 8px 12px;
            background-color: #dc3545;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h2>Manage Subjects</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Subject</th>
            <th>Number of Sets</th>
       
            <th>Created At</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['subject']) ?></td>
            <td><?= $row['no_of_set'] ?></td>
        
            <td><?= $row['created_at'] ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="subject" value="<?= htmlspecialchars($row['subject']) ?>">
                    <button type="submit" name="delete_subject" onclick="return confirm('Are you sure? This will delete all related sets.')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php $conn->close(); ?>
  