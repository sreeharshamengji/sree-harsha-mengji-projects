<?php
header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection error"]);
    exit;
}

$subject = $_GET["subject"] ?? "";
$setNumber = $_GET["set"] ?? 0;

if (!$subject || !$setNumber) {
    echo json_encode(["success" => false, "message" => "Missing parameters"]);
    exit;
}

// Sanitize subject (similar to your other scripts)
$subject = preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower(trim($subject)));
$tableName = "{$subject}_{$setNumber}";

// Query to count the total questions in this set
$query = "SELECT COUNT(*) as total FROM $tableName";
$result = $conn->query($query);
if ($result) {
    $row = $result->fetch_assoc();
    echo json_encode(["success" => true, "total" => (int)$row["total"]]);
} else {
    echo json_encode(["success" => false, "message" => "Query failed: " . $conn->error]);
}
$conn->close();
?>
