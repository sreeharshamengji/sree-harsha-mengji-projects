<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

// Database connection function
function connectDatabase() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "exam";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Create the subjects table if it doesn't exist
function initializeSubjectsTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS subjects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        subject_name VARCHAR(255) NOT NULL UNIQUE,
        no_of_set INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    if (!$conn->query($sql)) {
        die("Error creating subjects table: " . $conn->error);
    }
}

// Create a set-specific table for storing questions
function createSetTable($conn, $tableName) {
    $sql = "CREATE TABLE IF NOT EXISTS `$tableName` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        question TEXT NOT NULL,
        option_1 TEXT NOT NULL,
        option_2 TEXT NOT NULL,
        option_3 TEXT NOT NULL,
        option_4 TEXT NOT NULL,
        correct_option VARCHAR(10) NOT NULL
    )";
    if (!$conn->query($sql)) {
        die("Error creating set table $tableName: " . $conn->error);
    }
}

// Insert rows into a specific set table
function insertRows($conn, $tableName, $rows) {
    $sql = "INSERT INTO `$tableName` (question, option_1, option_2, option_3, option_4, correct_option) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    foreach ($rows as $row) {
        $stmt->bind_param(
            "ssssss",
            $row['question'],
            $row['option_1'],
            $row['option_2'],
            $row['option_3'],
            $row['option_4'],
            $row['correct_option']
        );
        $stmt->execute();
    }
    $stmt->close();
}

// Sanitize names to prevent SQL injection
function sanitizeName($name) {
    return preg_replace('/[^a-zA-Z0-9_]/', '_', strtolower(trim($name)));
}

// Main script to process the uploaded file
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = sanitizeName($_POST['subject']); // Sanitize subject name
    $setCount = intval($_POST['set_count']); // Number of sets
    $file = $_FILES['file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        die("File upload error. Please try again.");
    }

    // Move uploaded file
    $fileDestination = 'uploads/' . basename($file['name']);
    if (!is_dir('uploads')) {
        mkdir('uploads');
    }
    move_uploaded_file($file['tmp_name'], $fileDestination);

    // Connect to the database and initialize tables
    $conn = connectDatabase();
    initializeSubjectsTable($conn);

    // Check if the subject exists
    $stmt = $conn->prepare("SELECT * FROM subjects WHERE subject_name = ?");
    $stmt->bind_param("s", $subject);
    $stmt->execute();
    $result = $stmt->get_result();
    $subjectExists = $result->fetch_assoc();
    $stmt->close();

    if ($subjectExists) {
        // Update existing subject
        $stmt = $conn->prepare("UPDATE subjects SET no_of_set = ? WHERE subject_name = ?");
        $stmt->bind_param("is", $setCount, $subject);
    } else {
        // Insert new subject
        $stmt = $conn->prepare("INSERT INTO subjects (subject_name, no_of_set) VALUES (?, ?)");
        $stmt->bind_param("si", $subject, $setCount);
    }
    $stmt->execute();
    $stmt->close();

    // Load and process Excel file
    $spreadsheet = IOFactory::load($fileDestination);
    $sheet = $spreadsheet->getActiveSheet();
    $rows = $sheet->toArray(null, true, true, true);

    array_shift($rows); // Remove headers
    $groupedData = [];
    foreach ($rows as $row) {
        $set = intval($row['H']); // Get set number
        $groupedData[$set][] = [
            'question' => $row['B'],
            'option_1' => $row['C'],
            'option_2' => $row['D'],
            'option_3' => $row['E'],
            'option_4' => $row['F'],
            'correct_option' => $row['G']
        ];
    }

    // Insert data into respective set tables
    for ($set = 1; $set <= $setCount; $set++) {
        if (!isset($groupedData[$set])) {
            echo "Skipping set $set as no data exists for this set.<br>";
            continue;
        }
        $tableName = "{$subject}_set{$set}";
        createSetTable($conn, $tableName);
        insertRows($conn, $tableName, $groupedData[$set]);
        echo "Data for set $set saved into table $tableName.<br>";
    }

    echo "All data successfully saved!";
    $conn->close();
}
?>
