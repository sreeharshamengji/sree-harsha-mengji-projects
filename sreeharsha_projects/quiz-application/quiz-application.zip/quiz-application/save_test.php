<?php
header("Content-Type: application/json");

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Read JSON input from the client
$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    echo json_encode(["success" => false, "message" => "No data received."]);
    exit;
}

// Retrieve fields from the JSON payload
$subject = $data['subject'] ?? '';
$date = $data['date'] ?? '';
$time = $data['time'] ?? '';
$duration = isset($data['duration']) ? (int)$data['duration'] : 0;
$sets = $data['sets'] ?? [];

if (!$subject || !$date || !$time || !$duration || empty($sets)) {
    echo json_encode(["success" => false, "message" => "Missing required fields."]);
    exit;
}

// Compute the number of sets, total questions, and total marks
$no_of_set = count($sets);
$total_questions = 0;
$total_marks = 0;
foreach ($sets as $set) {
    $questions = isset($set['questions']) ? (int)$set['questions'] : 0;
    $marks = isset($set['marks']) ? (int)$set['marks'] : 0;
    $total_questions += $questions;
    $total_marks += ($questions * $marks);
}

// Database connection details
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Insert into tests table
    $query = "INSERT INTO tests (subject, no_of_set, duration, total_questions, total_marks, date, time) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("siiiiss", $subject, $no_of_set, $duration, $total_questions, $total_marks, $date, $time);
    if (!$stmt->execute()) {
        throw new Exception("Insert into tests failed: " . $stmt->error);
    }

    // Get the last inserted test_id
    $test_id = $stmt->insert_id;
    $stmt->close();

    // Insert each set into test_sets table
    $query = "INSERT INTO test_sets (test_id, set_number, question_count, marks_allotted) 
              VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Prepare failed for test_sets: " . $conn->error);
    }

    foreach ($sets as $index => $set) {
        $set_number = $index + 1;
        $questions = isset($set['questions']) ? (int)$set['questions'] : 0;
        $marks = isset($set['marks']) ? (int)$set['marks'] : 0;

        $stmt->bind_param("iiii", $test_id, $set_number, $questions, $marks);
        if (!$stmt->execute()) {
            throw new Exception("Insert into test_sets failed: " . $stmt->error);
        }
    }
    $stmt->close();

    // Commit transaction
    $conn->commit();
    $conn->close();

    echo json_encode(["success" => true, "message" => "Test and sets saved successfully."]);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    $conn->close();

    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
?>
