<?php
header("Content-Type: application/json");

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- Step 0: Validate the request method ---
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
    exit;
}

// --- Step 1: Retrieve the test ID from the POST data ---
$data = json_decode(file_get_contents("php://input"), true);
$testId = isset($data['testId']) ? (int)$data['testId'] : 0;
if (!$testId) {
    echo json_encode(["success" => false, "message" => "Test ID is required"]);
    exit;
}

// --- Step 2: Connect to the database ---
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "exam";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// --- Step 3: Fetch the test record from the tests table ---
$stmt = $conn->prepare("SELECT subject, no_of_set, duration, total_questions, total_marks, date, time FROM tests WHERE id = ?");
if (!$stmt) {
    echo json_encode(["success" => false, "message" => "Prepare (select) failed: " . $conn->error]);
    exit;
}
$stmt->bind_param("i", $testId);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Test not found"]);
    exit;
}
$testData = $result->fetch_assoc();
$stmt->close();

// --- Step 4: Create the previous_tests table if it does not exist ---
$createPrevTableSQL = "CREATE TABLE IF NOT EXISTS previous_tests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    no_of_set INT NOT NULL,
    duration INT NOT NULL,
    total_questions INT NOT NULL,
    total_marks INT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
if (!$conn->query($createPrevTableSQL)) {
    echo json_encode(["success" => false, "message" => "Failed to create previous_tests table: " . $conn->error]);
    exit;
}

// --- Step 5: Insert the record into previous_tests including all fields ---
// Note: The binding type string "siiiiss" corresponds to:
// subject (s), no_of_set (i), duration (i), total_questions (i),
// total_marks (i), date (s), time (s)
$stmt = $conn->prepare("INSERT INTO previous_tests (subject, no_of_set, duration, total_questions, total_marks, date, time) VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    echo json_encode(["success" => false, "message" => "Prepare (insert) failed: " . $conn->error]);
    exit;
}
$stmt->bind_param(
    "siiiiss",
    $testData['subject'],
    $testData['no_of_set'],
    $testData['duration'],
    $testData['total_questions'],
    $testData['total_marks'],
    $testData['date'],
    $testData['time']
);
if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Failed to insert into previous_tests: " . $stmt->error]);
    exit;
}
$stmt->close();

// --- Step 6: Delete the test record from the tests table ---
$stmt = $conn->prepare("DELETE FROM tests WHERE id = ?");
if (!$stmt) {
    echo json_encode(["success" => false, "message" => "Prepare (delete) failed: " . $conn->error]);
    exit;
}
$stmt->bind_param("i", $testId);
if (!$stmt->execute()) {
    echo json_encode(["success" => false, "message" => "Failed to delete test: " . $stmt->error]);
    exit;
}
$stmt->close();

echo json_encode(["success" => true]);
$conn->close();
?>
