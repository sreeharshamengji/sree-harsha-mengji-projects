<?php
require 'vendor/autoload.php';  // Load PHPSpreadsheet
require 'db.php'; // Database connection

use PhpOffice\PhpSpreadsheet\IOFactory;

if (isset($_POST['upload'])) {
    $subject_code = $_POST['subject_code'];

    // Ensure the subject_code is safe for table names
    $subject_code = preg_replace('/[^a-zA-Z0-9_]/', '_', $subject_code);

    // Check if the table already exists
    $check_table_query = "SHOW TABLES LIKE '$subject_code'";
    $result = $conn->query($check_table_query);

    if ($result->num_rows > 0) {
        die("Error: Subject '$subject_code' already exists! Please use a different subject code.");
    }

    // Ensure the uploads directory exists
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true);
    }

    // Check if file is uploaded
    if ($_FILES['excel_file']['error'] == 0) {
        $file_name = $_FILES['excel_file']['name'];
        $file_tmp = $_FILES['excel_file']['tmp_name'];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

        // Validate file extension
        if (!in_array($file_ext, ['xls', 'xlsx'])) {
            die("Invalid file format! Only XLS and XLSX allowed.");
        }

        // Move uploaded file to "uploads/" directory
        $upload_path = "uploads/" . basename($file_name);
        if (!move_uploaded_file($file_tmp, $upload_path)) {
            die("Failed to move uploaded file.");
        }

        // Read Excel File
        $spreadsheet = IOFactory::load($upload_path);
        $worksheet = $spreadsheet->getActiveSheet();
        $data = $worksheet->toArray();

        // Skip first row (Header)
        array_shift($data);

        // Create a new table for this subject
        $create_table_query = "CREATE TABLE `$subject_code` (
            id INT AUTO_INCREMENT PRIMARY KEY,
            serial_no INT,
            question TEXT,
            lesson_no INT
        )";

        if (!$conn->query($create_table_query)) {
            die("Error creating table: " . $conn->error);
        }

        // Prepare the insert query
        $stmt = $conn->prepare("INSERT INTO `$subject_code` (serial_no, question, lesson_no) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $serial_no, $question, $lesson_no);

        // Insert Data
        foreach ($data as $row) {
            $serial_no = $row[0];  // S.No
            $question = $row[1];   // Question
            $lesson_no = $row[2];  // Lesson No

            $stmt->execute();
        }

        echo "Data successfully imported into table: $subject_code!";
    } else {
        echo "Error uploading file!";
    }
}
?>
