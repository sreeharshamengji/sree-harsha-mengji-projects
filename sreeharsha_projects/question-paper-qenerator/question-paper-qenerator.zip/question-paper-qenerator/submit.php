<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $sub = $_POST['sub'];
    $sc = $_POST['sc'];
    $branch = $_POST['branch'];
    $nax_marks = $_POST['nax_marks'];
    $exam_name = $_POST['exam_name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $note = $_POST['note'];

    // Insert data into the database
    $sql = "INSERT INTO exam_details (subject, subject_code, branch, max_marks, exam_name, date, time, notes)
            VALUES ('$sub', '$sc', '$branch', '$nax_marks', '$exam_name', '$date', '$time', '$note')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        header("Location: qp.php"); // Redirect to the page that fetches and displays the details
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
