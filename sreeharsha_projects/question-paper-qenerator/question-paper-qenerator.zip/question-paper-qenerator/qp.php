
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Details</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Exam Details</h1>

        <?php
        // Connect to the database
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "exam_db";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch the data
        $sql = "SELECT * FROM exam_details";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='exam-card'>
                        <h2>" . $row["exam_name"] . "</h2>
                        <p><strong>Subject:</strong> " . $row["subject"] . "</p>
                        <p><strong>Subject Code:</strong> " . $row["subject_code"] . "</p>
                        <p><strong>Branch:</strong> " . $row["branch"] . "</p>
                        <p><strong>Max Marks:</strong> " . $row["max_marks"] . "</p>
                        <p><strong>Date:</strong> " . $row["date"] . "</p>
                        <p><strong>Time:</strong> " . $row["time"] . "</p>
                        <p><strong>Notes:</strong> " . $row["notes"] . "</p>
                      </div>";
            }
        } else {
            echo "No records found.";
        }

        $conn->close();
        ?>

    </div>
</body>
</html>
