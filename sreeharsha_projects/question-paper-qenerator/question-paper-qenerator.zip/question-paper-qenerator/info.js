
document.addEventListener('DOMContentLoaded', function() {
    const examDetails = JSON.parse(localStorage.getItem('examDetails'));
    const qpDetails = JSON.parse(localStorage.getItem('qpDetails'));

    if (examDetails && qpDetails) {
        document.getElementById('subjectCode').textContent = examDetails.subjectCode;
        document.getElementById('examName').textContent = examDetails.examName;
        document.getElementById('time').textContent = examDetails.time;
        document.getElementById('maxMarks').textContent = examDetails.maxMarks;
        document.getElementById('subject').textContent = examDetails.subject;
        document.getElementById('branch').textContent = examDetails.branch;
        document.getElementById('date').textContent = examDetails.date;
        document.getElementById('note').textContent = examDetails.note;

        // Fetch questions from PHP
        fetch(`fetch_questions.php?subjectCode=${qpDetails.subjectCode}&lessonData=${encodeURIComponent(JSON.stringify(qpDetails.lessonData))}`)
            .then(response => response.json())
            .then(data => {
                let qtSection = document.querySelector('.qt');
                qtSection.innerHTML = ""; 

                data.forEach((question, index) => {
                    let div = document.createElement('div');
                    div.classList.add('q');
                    div.innerHTML = `<p>Q${index + 1}: ${question}</p>`;
                    qtSection.appendChild(div);
                });
            })
            .catch(error => console.error('Error fetching questions:', error));
    }
});

