# 🧠 Question Paper Generator

## 📚 Overview
A dynamic web-based system for preparing and managing exam question papers. This application allows educators to create structured question papers by selecting units and specifying the number of questions per unit.

## ✨ Features

### 🎯 Core Functionality
- **Subject Verification**: Instantly verify if a subject exists in the database
- **Dynamic Unit Selection**: Automatically detect available units for each subject
- **Flexible Question Allocation**: Allocate different numbers of questions to different units
- **Smart Validation**: Prevent duplicate unit selection and ensure all fields are filled
- **Data Persistence**: Save question paper structure to localStorage for later use

### 🎨 User Interface
- **Clean, Modern Design**: Intuitive interface with clear visual hierarchy
- **Responsive Layout**: Works well on different screen sizes
- **Interactive Elements**: Add/remove unit-question pairs with a single click
- **Visual Feedback**: Clear success/error messages and loading states

### 🔄 Workflow
1. Enter and verify a subject code
2. Add unit-question pairs as needed
3. Select units and specify question counts
4. Save the question paper structure
5. Redirect to entry page for further processing

## 🛠️ Technical Details

### Frontend
- **HTML5**: Semantic markup for better accessibility
- **CSS3**: Modern styling with flexbox for responsive layouts
- **JavaScript**: Dynamic DOM manipulation and data management
- **LocalStorage API**: Client-side data persistence

### Backend
- **PHP**: Server-side validation and database interaction
- **MySQL/MariaDB**: Relational database for storing subject and question data
- **RESTful API**: Simple API for subject verification

## 🚀 Getting Started

### Prerequisites
- Web server (Apache, Nginx, etc.)
- PHP 7.4+ with MySQL/MariaDB support
- Modern web browser with JavaScript enabled

### Installation
1. Clone this repository to your web server directory
2. Import the provided SQL file to create the database structure
3. Configure your database connection in `db.php`
4. Access the application through your web browser

### Database Structure
- Each subject has its own table named after the subject code
- Tables contain columns for:
  - `id`: Unique identifier
  - `serial_no`: Question serial number
  - `question`: The actual question text
  - `lesson_no`: Unit/lesson number

## 📝 Usage Guide

### Preparing a Question Paper
1. Open `prepare_qp.html` in your browser
2. Enter the subject code and click "Verify"
3. Once verified, you'll see the available units
4. Select a unit and specify the number of questions
5. Click "+" to add more unit-question pairs
6. Click "Save" when finished
7. You'll be redirected to the entry page

### Managing Units
- Each unit can only be selected once
- You must have at least one unit-question pair
- The number of questions must be a positive integer

## 🔍 Troubleshooting

### Common Issues
- **Subject Not Found**: Verify the subject code exists in the database
- **No Units Available**: Check if the subject table has lesson_no values
- **Save Error**: Ensure all fields are filled and no duplicate units are selected

### Debug Tips
- Check browser console for JavaScript errors
- Verify database connection settings
- Ensure proper file permissions

## 🔒 Security Considerations
- Input sanitization for database queries
- Client-side validation for user inputs
- Server-side validation for critical operations

## 📈 Future Enhancements
- User authentication system
- Question bank management
- PDF export functionality
- Question paper templates
- Analytics dashboard

## 📄 License
This project is licensed under the MIT License - see the LICENSE file for details.

## 👥 Contributors
- Your Name - Initial work

## 🙏 Acknowledgments
- Thanks to all contributors who have helped improve this project
- Special thanks to the open-source community for inspiration and tools 