<?php
// Set error reporting and output buffering at the very top
error_reporting(0);
ini_set('display_errors', 0);
ob_start();

require 'db.php'; // Database connection

// Clear any previous output
ob_clean();

// Set JSON header
header('Content-Type: application/json');

try {
    if (!isset($_GET['subject_code'])) {
        throw new Exception('Subject code not provided');
    }

    $subject_code = preg_replace('/[^a-zA-Z0-9_]/', '_', $_GET['subject_code']);

    // Check database connection
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception('Database connection failed');
    }

    $check_table_query = "SHOW TABLES LIKE '$subject_code'";
    $result = $conn->query($check_table_query);

    if ($result->num_rows > 0) {
        // Count distinct units in the subject's table
        $count_units_query = "SELECT COUNT(DISTINCT lesson_no) as unit_count FROM `$subject_code`";
        $units_result = $conn->query($count_units_query);
        
        if ($units_result) {
            $row = $units_result->fetch_assoc();
            $unit_count = (int)$row['unit_count'];
            echo json_encode([
                'status' => 'exists',
                'unit_count' => $unit_count
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Error counting units'
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'not found',
            'message' => 'Subject not found'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}

// Close the database connection if it exists
if (isset($conn)) {
    $conn->close();
}

// End output buffering and send output
ob_end_flush();
?>
