CREATE DATABASE question_db;

USE question_db;

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    serial_no INT NOT NULL,
    question TEXT NOT NULL,
    lesson_no VARCHAR(10) NOT NULL
);
