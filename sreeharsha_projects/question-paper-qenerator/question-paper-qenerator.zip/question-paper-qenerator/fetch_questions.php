<?php
header("Content-Type: application/json");

$host = "localhost";
$user = "root";
$password = "";
$database = "question_db";  // Change this to your actual database name

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Database connection failed"]));
}

$method = $_SERVER['REQUEST_METHOD'];

// Handle GET request (fallback)
if ($method == "GET") {
    if (!isset($_GET["subject_code"])) {
        echo json_encode(["success" => false, "error" => "Missing subject_code"]);
        exit;
    }

    $subject_code = $_GET["subject_code"];
    $table_name = $conn->real_escape_string($subject_code);
    $query = "SELECT question, lesson_no FROM `$table_name` LIMIT 10"; // Fetch 10 random questions
    $result = $conn->query($query);
    $questions = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode(["success" => true, "questions" => $questions]);
    exit;
}

// Handle POST request (main method)
$input = json_decode(file_get_contents("php://input"), true);
if (!isset($input["subject_code"]) || !isset($input["lessons"])) {
    echo json_encode(["success" => false, "error" => "Invalid request parameters"]);
    exit;
}

$subject_code = $input["subject_code"];
$table_name = $conn->real_escape_string($subject_code);
$questions = [];

foreach ($input["lessons"] as $lesson) {
    $lesson_no = intval($lesson["lesson_no"]);
    $num_questions = intval($lesson["num_questions"]);

    // Updated to include lesson_no in the selection
    $query = "SELECT question, lesson_no FROM `$table_name` WHERE lesson_no = ? ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $lesson_no, $num_questions);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $questions[] = $row;
    }
    $stmt->close();
}

$conn->close();
echo json_encode(["success" => true, "questions" => $questions]);
?>